# GOD4.us English Ethiopian Canon: 84-entry bundle

Excludes 4 Baruch. Public-domain English texts in the United States. This is an English reading collection, not a complete or official canon edition.
Some works use related translations rather than the exact Ethiopic recension; see the source notes.

`js/bible/eth.js` defines `ethLibrary`. All 79 original book objects and their relative order are unchanged.
The combined file has 41,740 verse slots, including 21 blank slots preserved from the source numbering.
The five church-order texts follow Revelation. 

The original 79-book documentation is preserved as a snapshot. The additions have separate source
and editing notes in `docs/ETHIOPIAN-ADDITIONS-SOURCES.md`. The additional text was spot-checked,
not proofread word for word. Some new texts have sentence-based numbering rather than traditional verses.

This is a data file only. It has not been registered in the GOD4.us Reader, pushed to GitHub, or deployed.
Use only one version of `eth.js` at a time.
