# Ethiopian Canon (English, public domain)

`js/bible/eth.js` defines `ethLibrary`, an English reading edition of the books of the
Ethiopian Orthodox Tewahedo canon that have a **public-domain** English translation. It uses the
same data shape as the other translation bundles (`{ bookId: { name, chapters, 1: { title, verses: [...] } } }`).

The bundle is **data only**. It is not yet registered in `js/bible/data.js`, the translation loader,
or the translation manifest, so it does not appear on the site.

## Contents (79 books, 37,603 verses)

| Books | Translation | Status | Source |
|---|---|---|---|
| The 66 books of the Protestant canon | King James Version, 1769 text | Public domain outside the UK | Copied unchanged from `js/bible/kjv.js` (eBible.org / CrossWire) |
| Psalm 151 (added as Psalms chapter 151) | Sir Lancelot C. L. Brenton, *The Septuagint* (1851) | Public domain | eBible.org `eng-Brenton_usfm.zip` — https://ebible.org/eng-Brenton/ |
| 1 Enoch (108 chapters) | R. H. Charles, *The Book of Enoch* (SPCK, 1917) | Public domain (published before 1931) | https://archive.sacred-texts.com/bib/boe/ |
| Jubilees (50 chapters) | R. H. Charles, *The Book of Jubilees* (SPCK, 1917) | Public domain (published before 1931) | https://archive.sacred-texts.com/bib/jub/ |
| Tobit, Judith, Wisdom of Solomon, Sirach, Baruch (incl. Letter of Jeremiah as ch. 6), Prayer of Azariah, Susanna, Bel and the Dragon, Prayer of Manasseh, 1 Esdras, 2 Esdras | KJV Apocrypha, 1769 text | Public domain outside the UK | eBible.org `eng-kjv_usfm.zip` — https://ebible.org/eng-kjv/ |

Book order: the 39 Old Testament books, then 1 Enoch, Jubilees and the eleven Apocrypha books
(between Malachi and Matthew), then the 27 New Testament books.

## Not included

These parts of the Ethiopian canon have no public-domain English translation that could be found,
or were left out on purpose:

- **1, 2 and 3 Meqabyan** — the only complete English translations are copyrighted. (A Wikisource
  community translation of 2 Meqabyan exists under CC BY-SA, which is not public domain.)
- **4 Baruch (Paralipomena of Jeremiah)** — not included in this first pass.
- **Additions to Esther** — the KJV prints them as a separate book starting at chapter 10, which
  does not fit the bundle's chapter model.
- **Broader-canon New Testament books** (Sinodos, Book of the Covenant, Ethiopic Clement, Didascalia).
- **1 and 2 Maccabees** — these are not part of the Ethiopian canon (it uses the Meqabyan instead).

## Notes on the Charles texts

- Charles's editorial brackets (⌈ ⌉, 〈 〉) and corruption marks (†) are removed; the words inside
  them are kept. Square brackets `[ ]` (his interpolation marks) and parentheses `( )` (words he
  supplied) are kept, as are his `...` lacuna marks.
- Page numbers, footnote numbers, footnotes, section headings and marginal Anno Mundi dates are removed.
- Charles moves some verses. In 1 Enoch, 91:12–17 appears after chapter 93 in his edition; the
  importer puts those verses back in chapter 91. Sub-verses such as "14 a", "b" are merged into their verse.
- 21 verse numbers are not marked in the sacred-texts transcription, so their text is inside the
  previous verse and the verse itself is empty:
  1 Enoch 10:7, 10:14, 10:16, 14:10, 16:3, 18:6, 22:4, 25:2, 25:3, 46:3, 60:5, 60:16, 76:13, 82:14,
  90:14, 90:15, 90:19, 93:2, 106:17; Jubilees 13:25, 25:10.
- A few misprinted verse numbers in the Jubilees transcription are corrected in the importer (see
  `jubileesErrata` in `tools/import-ethiopian-canon.js`).

## Rebuilding

Download the sources into `vendor/ethiopian-canon/` (ignored by git):

```
vendor/ethiopian-canon/
  kjv-usfm/          unzip https://ebible.org/Scriptures/eng-kjv_usfm.zip
  brenton-usfm/      unzip https://ebible.org/Scriptures/eng-Brenton_usfm.zip
  charles-enoch/     boe004.htm … boe112.htm from https://archive.sacred-texts.com/bib/boe/
  charles-jubilees/  jub12.htm … jub87.htm from https://archive.sacred-texts.com/bib/jub/
```

sacred-texts.com refuses requests without a browser User-Agent header.

Then run:

```
node tools/import-ethiopian-canon.js
node tests/validate-ethiopian-canon.js
```

## To show it on the site (not done yet)

1. Add an `eth` entry to `js/bible/data.js` (name "Ethiopian Canon (English)", abbreviation "ETH",
   provider `eth-library`) with the attribution above, and map `eth-library` to `ethLibrary`.
2. Add `eth: 'js/bible/eth.js'` to `js/bible/translation-loader.js` (and the translation manifest
   on branches that have it).
3. Check that Reader, Search and Compare handle books that other translations don't have
   (for example, choosing 1 Enoch and then switching to WEB).
