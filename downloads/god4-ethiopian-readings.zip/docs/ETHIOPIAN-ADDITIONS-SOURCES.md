# Ethiopian-Canon Additions for GOD4.us — Sources and Notes

Sources for the 5 texts added to `js/bible/eth.js`.

| Book id | Display name | Chapters | Verses | Translation | Status |
|---|---|---|---|---|---|
| sinodos-statutes | Sinodos: Statutes of the Apostles | 86 | 919 | George Horner, 1904 (Ethiopic recension) | Public domain |
| apostolic-canons | Sinodos: Apostolic Canons | 57 | 166 | George H. Schodde, 1885 | Public domain |
| testament-of-our-lord | 1 Dominos (Testament of Our Lord) | 74 | 804 | Cooper & Maclean, 1902 (from Syriac) | Public domain |
| epistle-of-the-apostles | 2 Dominos (Epistle of the Apostles) | 51 | 327 | M. R. James, 1924 | Public domain (US) |
| didascalia | Didascalia | 43 | 1,921 | J. M. Harden, 1920 | Public domain (US) |

## Important for all books
- For sources without verse numbers, the verse numbering is editorial. Verses are one sentence each — this is GOD4.us's own versification, not a traditional one. Cite by chapter (and the source's section name in the chapter title).
- Editors' introductions, footnotes, apparatus and running heads are removed. Text was cleaned from scans; it has been spot-checked but not proofread word by word.

---


# Sinodos: Statutes of the Apostles (book id: sinodos-statutes)

- Source: George Horner, "The Statutes of the Apostles, or Canones Ecclesiastici" (London: Williams & Norgate, 1904).
- Translator: George William Horner. The English is his translation of the ETHIOPIC text. The Arabic and Saïdic translations in the same volume were NOT used.
- archive.org: https://archive.org/details/statutesapostle00unkngoog (PDF: https://archive.org/download/statutesapostle00unkngoog/statutesapostle00unkngoog.pdf)
- Page range used: printed pp. 127–232 (PDF pages 174–279), "Statutes of the Apostles. Translation of the Ethiopic Text". I checked this against the page images: p. 127 opens the Ethiopic translation, and p. 232 ends with the "Prayer for the Papas" (Amen). The Arabic translation begins on p. 233.
- Copyright: public domain (published in 1904; the author died in 1930).

## Text production
- I ran fresh OCR (tesseract, 300 dpi) on the page images and kept the word positions. Margin line numbers, running heads, page numbers and the footnote blocks were removed using the page layout.
- I aligned the result word by word against the archive.org OCR. Every disagreement between the two was resolved by checking the page image. I also checked punctuation disagreements at sentence boundaries against the image.
- I removed footnote reference markers (about 45) after locating each one in the image.
- I joined words broken across lines. Real compounds were kept with their hyphen: star-gazer, first-fruits, door-posts, threshing-floor, grown-up, double-tongued, out-gushing. Line-break splits such as sub-deacon and hand-maids were joined, since Horner prints subdeacon and handmaids within lines.
- I normalised Horner's spaced " ;" and " :" to ";" and ":".
- Diacritics: Horner writes transliterated names with macrons and sub-dots (Mātēwos, Ḳēfās, Amēn, Bala'ām). The OCR could not reproduce these reliably (it read ē as é and sometimes ā as é or "d"). For consistency, all diacritics were removed (Matewos, Kefas, Amen, Bala’am). I checked doubtful names against the images, for example Samyas (not "Samydas"), Bala’am, Bi’or, Iyurebe’am and Endreyas. Horner's ʿ/ʾ apostrophes are kept as ’ where the OCR caught them. A leading ʿ was lost in "Ozyan" in two places (Horner prints ’Ozyān); it is kept as "’Ozyan".
- I removed Horner's half-bracket sigla (⌜ ⌝), which he uses to mark passages, for example in Statutes 16 and 52. His own (parentheses) for supplied words and "(lit. …)" glosses are kept. Some places where the OCR turned the italic "lit." into junk were restored to "(lit.". His lacuna "service . . . . that" (Statute 72) is written "service... that".

## Versification
- Chapters follow Horner's statute numbers in order (rule 1). Horner prints "Statute 40" TWICE: once for the long "ordinance of the gift … (with the order of Baptism)" (pp. 162–178), and again for "Concerning the fruit which it is seemly to offer" (p. 178). Chapters are numbered continuously, so:
  - ch. 1–40 = Statutes 1–40 (first)
  - ch. 41 = "Statute 40 (second statute so numbered by Horner)"
  - ch. 42–73 = Statutes 41–72 (chapter = statute + 1)
  - Each chapter title carries Horner's statute number.
- The opening invocation ("In the name of the Father … in the name of our Lord Jesus Christ.") comes before Statute 1 and is placed at the start of chapter 1.
- After Statute 72, Horner prints 13 unnumbered prayers. They belong to the Ethiopic text, so they are included as ch. 74–86, each titled by Horner's heading (for example "Prayer of Early Morning", "Prayer for the Papas").
- Titles: when a statute opens with Horner's heading sentence "Concerning …", that sentence is used in the title, e.g. "Statute 14. Concerning the ordination of a Bishop.", and is not repeated in the verses. Otherwise the title is "Statute N".
- Verses: Horner has no verse or paragraph numbers, so verses are split at sentence boundaries (rule 2) with the shared splitter tools/sentences.py (fragments under about 25 characters are merged). Some liturgical sentences are very long (up to about 1,300 characters); they are kept as single sentences.

## Counts
- Chapters: 86 (73 statute chapters + 13 prayers)
- Verses: 919

## Omissions / unresolved
- I omitted the editor's footnotes and textual variants (for example "Reading the variant of b c d e", Dillmann references).
- No unresolved readings remain that I know of. Residual risk: small punctuation errors (comma vs. full stop) where both OCRs agreed but were wrong.

## Differences from the Ethiopic tradition stated by the source
- Horner's footnotes note that the Ethiopic was translated from the Arabic. Some passages are probably corrupt or misread from the unpointed Arabic (e.g. Statute 16, Statute 35's "ticket"/Rev. 2:17, Statute 72 "send" for "describe"). Ludolf's printed text ends partway through Statute 24. These notes are not reproduced in the text.
- The duplicate "Statute 40" is Horner's own numbering (following his MSS), not an error introduced here.

---

# Sinodos: Apostolic Canons

- Source: George H. Schodde, "The Apostolic Canons, Translated from the Ethiopic", Journal of the Society of Biblical Literature and Exegesis, vol. 5 (1885), pp. 61–72.
- URL: https://archive.org/details/jstor-3268629 (JSTOR Early Journal Content, free to use)
- Copyright status: public domain (1885).
- Translated from: Ge'ez (Ethiopic). Sources disagree on whether this collection corresponds to the Sinodos section called Abtelis or Gessew.
- Used: the "Translation" section only (Schodde's introduction omitted). The short prologue ("In the name of the Father ...") is placed at the start of chapter 1.
- Versification: chapters = Schodde's canon numbers (I–LVII). Schodde has no verse numbers, so each canon is split into sentence verses (site's own versification, not traditional).
- Counts: 57 chapters, 166 verses.
- OCR fixes: "Canon XL" → "Canon XI", "Canon XL1I" → "Canon XLII", "psalmsingers" → "psalm-singers", printer's "brethern" → "brethren"; line-break hyphens joined; page headers removed.

---

# 1 Dominos (Testament of Our Lord) — notes

- Book id: `testament-of-our-lord`
- Source: James Cooper & Arthur John Maclean, *The Testament of Our Lord, translated into English from the Syriac, with introduction and notes* (Edinburgh: T. & T. Clark, 1902).
- Translators: James Cooper and Arthur John Maclean (from the Syriac text edited by Rahmani, 1899).
- archive.org: https://archive.org/details/cu31924029296170 (PDF: https://archive.org/download/cu31924029296170/cu31924029296170.pdf)
- Page range used: printed pp. 49–138 (PDF pages 69–158), i.e. the translation of Book I and Book II only.
- Copyright: public domain (published 1902; both translators died before 1930).

## What is included / excluded
- Included: the superscription ("The Testament, or Words which our Lord ... spake to the holy Apostles ..."), the unnumbered opening narrative before Book I chapter 1, Book I chapters 1–47, Book II chapters 1–27, and the closing colophons ("The First Book of Clement is ended", "John and Peter and Matthew wrote this Testament ...", "The Second Book of Clement is ended, translated from the Greek to the Syrian language by James the poor, in the year 998 of the Greeks").
- Excluded: title page, preface, introduction (pp. 1–48), all footnotes, running heads and page numbers, the Notes (pp. 139 ff.), the appendices and the index.
- Appendix I is "The Abyssinian Anaphora of our Lord" — an Ethiopic liturgical text derived from the Testament, translated by the editors from Ludolf's Latin. Not included. Appendix II (last chapter of the Arabic Didascalia) is also not included.

## Structure / versification
- Chapters: the translation's own chapter numbers, numbered continuously: JSON chapters 1–47 = Book I ch. 1–47; JSON chapters 48–74 = Book II ch. 1–27. Each title gives the original label, e.g. "Book II, Chapter 3". Where a section heading comes straight after the chapter number, it is added to the title (e.g. "Book I, Chapter 40: Of widows"; "Book II, Chapter 13: [The Agapé]"). Book I ch. 19 is set as "[Chapter 19]" because the translators supplied that number in brackets.
- The superscription plus "The First Book." is verse 1 of chapter 1, and the unnumbered opening narrative follows as chapter 1's first verses, so that JSON chapter n always matches Book I chapter n. In the same way, the Book II superscription ("The Second Book of Clement. Commandments and rules and a definition ...") is verse 1 of Book II ch. 1 (JSON 48).
- Verses: the source has no verse numbers, so I used SPEC rule 2: each paragraph is split at sentence boundaries using tools/sentences.py, one sentence per verse, with fragments under ~25 characters merged. Sentences are never split across paragraphs. Section headings that come in the middle of a chapter (e.g. "Prayer of ordination of a bishop", "Hymn of praise for the dawn", "Exorcism before the laver") are kept as their own short verse, in sentence case, without a final period. Short stand-alone liturgical responses such as "The people: Amen." stay as separate verses.
- Counts: 74 chapters, 804 verses. Some verses are very long (up to ~2,950 characters) because some prayers are single sentences joined by semicolons.

## Text cleanup method
- I extracted the text from archive.org's character-level OCR (chocr), which gives the position of every character. That let me remove raised footnote markers and leave out the smaller-type footnotes and the running heads. Words broken by line-end hyphens were rejoined, but real compounds were kept (e.g. "Only-begotten", "blue-black").
- Footnote markers that the OCR read as stray symbols (® ° § * + ? ’ ! etc.) were removed. Where a marker had swallowed the period or comma before it, I put that punctuation back. Doubtful cases were checked against the page images.
- OCR fixes I checked against the page images include: It came (Ir), I tell (T tell), If (Lf/Tf), let (Jet), up (wp), I am / I believe (J/T), Illuminator, Uncreated, Earnestly, condemned, beginneth, receiveth, flesh, East (Hast), "this type", "Woe is me!", "[of the clergy be polluted]", "[to be received back].", "in the night", "For their deeds", and several stray digits.
- Editorial additions: in two places the printed page has no full stop between sentences, and I added one: "the people of piety. Let him admonish" (Book I ch. 35) and "the service of the priesthood. Her requests" (Book I ch. 40).
- Italic passages in the source (which the translators use for some rubrics and interpolations) are given as plain text.
- Unresolved: none known. The extraction was checked heavily but not proofread word by word, so a few OCR errors that happen to form real words may remain.

## Differences from the Ethiopic tradition (as stated by the source)
- This is a translation of the Syriac version (Rahmani's text), not of the Ethiopic. The editors note that two copies of an Ethiopic translation exist in the British Museum, unpublished in 1902, "of uncertain age, perhaps made from the Coptic or from the Arabic" (Introduction, p. 7).
- The superscription says the work was "written in eight books by Clement". The Syriac Testament as translated here has only two books.
- In Book I ch. 23, the Syriac Testament leaves out our Lord's words over the Cup. The editors state that the Ethiopic translation fills this gap, interpolating: "Also the cup of wine which He mixed, He gave to His disciples, saying, Take drink it all of you. This is My blood which is shed for you" (Notes, pp. 170–171). Those words are not in this text.
- The editors also mention a Rahmani conjecture based on the Ethiopic translation at one point in Book I ch. 23 (a footnote). The text here follows the Syriac translation as printed.
- The derived Ethiopic "Anaphora of our Lord" (Appendix I) is a separate, later text and is not included.

---

# 2 Dominos (Epistle of the Apostles / Epistula Apostolorum)

- Source: Montague Rhodes James, "The Apocryphal New Testament" (Oxford: Clarendon Press, 1924), pp. 485–503, "The Epistle of the Apostles".
- URL: https://en.wikisource.org/wiki/The_Apocryphal_New_Testament_(1924)/Epistles/The_Epistle_of_the_Apostles (proofread transcription of the 1924 printing)
- Copyright status: public domain in the US (published 1924); James died in 1936, so it is also out of copyright in life+70 countries.
- Translated from: Ethiopic, Coptic and Latin witnesses (James follows Schmidt and Guerrier). James's own note: the Ethiopic version prefixes a prophecy ("Testament in Galilee"), which he does not translate in full — it is not included here.
- Versification: chapters = James's section numbers 1–51. James has no verse numbers, so sections are split into sentence verses (site's own versification). Sentences are not split inside parentheses.
- Counts: 51 chapters, 327 verses.
- Kept: James's inline variant readings, e.g. "(Sarrha, Eth.)", "(so Copt.: ...)", "(?)", because they are part of his translation and show where the Ethiopic differs.
- Removed: James's introduction and boxed notes, parallel-passage tables, footnotes, and purely editorial remarks ("Here begins the Coptic text", "Six leaves lost in Copt.: Eth. continues", "Copt. resumes", "Copt. defective from this point", "the verbs might well be transposed", "Here the Latin omits ...", "It is an interpolation ...", "Cf. the Marcosian story ...", "In Copt. and Eth. the general sense is the same ..."). "[a leaf lost in Copt.]" shown as "[...]".
- Angle brackets ‹supplied text› converted to ⟨ ⟩ so they display safely in a web page.
- Note: 3:1 is long (about 1,200 characters) because it is a single creed-like sentence in James.

---

# Didascalia (Ethiopic)

- Source: J. M. Harden, "The Ethiopic Didascalia" (Translations of Christian Literature, Series IV: Oriental Texts), London: SPCK; New York: Macmillan, 1920.
- Translator: James Methuen Harden.
- Year: 1920.
- URL: https://archive.org/details/cu31924096083336 (PDF: https://archive.org/download/cu31924096083336/cu31924096083336.pdf)
- Copyright status: public domain in the US (published 1920, before 1929).
- Translated from: Ge'ez (Ethiopic), British Museum MS Orient. 752, with chapter titles collated against Orient. 793, 797, 798, 799 (per Harden's introduction).
- Page range used: book pp. 1–188 (translation only; PDF pages 29–217). The introduction (pp. vii–xxiii), footnotes, the marginal/bracketed cross-references to the Apostolic Constitutions (e.g. "[ii., 15.]"), running heads, page numbers and the index were left out.
- Output file: out/didascalia.json

## Structure and versification

- Chapters = Harden's 43 chapters (i.–xliii.). Each chapter's title is Harden's heading, written in sentence case. Chapter 1's title is "The Doctrine of the Didascalia of the Fathers, the Holy and Pure Lights of the World, the Apostles". The invocation ("In the name of God the Father Almighty ... and the Holy Spirit.") is verse 1 of chapter 1.
- Chapter 25's title keeps Harden's bracketed addition "[Of the feasts of the Passover.]".
- Chapter 42 has no title in the source (Harden's introduction says "no title in Eth."), so its title is an empty string.
- The closing colophon at the end of chapter 43 ("Here endeth the doctrine of the Didascalia ... Bakafla and with his wife, Wald Saala, for ever and ever Amen.") is part of the translated text, so it is kept.
- Versification rule: SPEC rule 2. Harden has no verse numbers, so verses are sentence splits made for this site (not traditional). The text was split at sentence boundaries, fragments under about 25 characters were merged, and quotations and parentheses were not split.
- Counts: 43 chapters, 1921 verses (shortest 25 chars; median 135; longest 1570 chars, ch. 38 v. 9, a long prayer with no sentence break).

## Editorial handling

- The book was re-OCR'd at 300 dpi with tesseract and reconciled word by word with the archive.org djvu text. Unclear spots were checked against the page images.
- Line-break hyphens were joined. Real compounds were kept (to-day, father-in-law, feast-days, High-priest, only-begotten, etc.).
- Footnote reference numbers/superscripts were removed. Superscripts that OCR had read as "1", "!" or "|" where the word was really "I" were restored (e.g. "Lord, is it I?", "Behold I have taught you").
- Harden's obelus daggers (†...†) around corrupt or doubtful words were removed and the words kept (e.g. Apis, Lois, Nicolas, Marthones, Saturnilus, Haman, Holofernes).
- Translator's ( ) supplements, [ ] additions, "(?)" queries and ". . ." gaps are kept as printed (". . ." normalised to "...").
- The æ ligature is written as "ae" (Zacchaeus, Judaea, Caesarea). Diacritics in "Benomnimĕn" and "sābăqtani" are kept as printed. "Magdelene" (used alongside "Magdalene") is kept as printed.
- Curly quotes are used throughout.

## Unresolved / known issues

- Quotation marks: about 80 places where double quotes still don't balance (an opening quote with no close, or a close with no opening). These come mostly from closing quotes that ran into footnote superscripts in the print, or from long quotations that span several verses. Nesting was not reconstructed. A few single-quote openings (e.g. "‘Ye are my sons...’", "‘Turn thy face from my sin...") are kept as OCR read them.
- Some stray footnote-marker residue or minor OCR misreadings may still remain. Proper names were checked against wordfreq/zipf, but common-word errors (e.g. "arc" for "are", now fixed) can only be caught by reading, and not every chapter was read in full.
- Very long verses in the liturgical chapters (33–39) come from long single sentences in Harden. They were not cut at arbitrary points.

## Differences from Ethiopic / related tradition stated by the source

- Harden translates one manuscript (BM Orient. 752) throughout. Four of the five BM MSS divide the work into 43 chapters. MS 798 and Platt's MS join chapters iv. and v. under one title.
- Platt's 1834 edition covers only chapters i.–xxiii.a (his manuscript was defective: a leaf is lost in its ch. xvi and it breaks off mid-word in its ch. xxii, i.e. chapters xvii and xxiii of Harden's numbering). Chapters xxiii.b–xliii. are translated here for the first time.
- The Ethiopic Didascalia follows the second Arabic recension (Apostolic Constitutions i.–vii.), not the first recension with its six extra chapters.
- Compared with Apostolic Constitutions i.–vii., 46, the Ethiopic has nothing matching i., 9; ii., 48, 52; vii., 13, 18–26. Harden thinks the long gap (vii., 18–26, including the "way of death" and the eucharist) is accidental (compare the title of ch. xxxv, "Of toil and thanksgiving"). The final doxology may be a fragment of AC vii., 47. AC vii., 49 (thanksgiving after meat, Arabic II xliv.) is missing.
- Arabic (II) differs in chapter division and titles at several points (e.g. Arabic xx., xxv., xxvii., xxxvi. have no Ethiopic chapter to match, and Ethiopic xlii. has no title).

---
