# GOD4.us Ethiopian Readings — offline edition

Extract the ZIP and open Read Ethiopian Collection.html in a web browser.
The book and chapter pickers work offline. Read Aloud uses an installed offline
English voice. The Meqabyan links require an internet connection.

The reader includes the 84 provided English entries and two related works,
2 Enoch and 3 Enoch. 1 Enoch belongs to the Ethiopian Orthodox biblical
tradition. 2 and 3 Enoch are companion works. See docs for the original
collection’s source notes and coverage.

## New text sources

- 2 Enoch — The Book of the Secrets of Enoch, in Rutherford H. Platt Jr., ed.,
  The Forgotten Books of Eden (1926), chapters 1–68. This historical edition
  ends at chapter 68. Some other editions include a Melchizedek continuation.
  https://en.wikisource.org/wiki/The_Forgotten_Books_of_Eden/The_Book_of_the_Secrets_of_Enoch
- 3 Enoch — Hugo Odeberg, 3 Enoch or The Hebrew Book of Enoch (1928).
  Historical English text as transcribed by Margins. All 54 numbered and
  lettered sections in that transcription, retaining its section labels.
  https://margins.bible/3-enoch/
  Original edition record: https://openlibrary.org/books/OL14026382M/3_Enoch

These historical English editions are public domain in the United States.
Source numbering and wording were retained as transcribed, with HTML markup
and excess whitespace removed. Individual readings were not proofread
against the originals.

## Online Meqabyan readings

These publisher links are included in the reader and require internet access.
The complete translations in the publisher’s edition are copyrighted and
were not added to the offline collection.

- https://ethiopiancanon.com/read/1-meqabyan
- https://ethiopiancanon.com/read/2-meqabyan
- https://ethiopiancanon.com/read/3-meqabyan
